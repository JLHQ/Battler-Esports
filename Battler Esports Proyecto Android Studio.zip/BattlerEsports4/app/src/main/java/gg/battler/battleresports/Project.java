package gg.battler.battleresports;

public class Project {

    String name;
    String description;
    int image;

    public Project(String name, String description, int image) {
        this.name = name;
        this.description = description;
        this.image = image;
    }

}
